/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlist;

/**
 *
 * @author deand
 */
public class PlaylistApp {

    public static void main(String[] args) {
        PlaylistGUI myGUI = new PlaylistGUI();
        myGUI.setVisible(true);
    }
}
